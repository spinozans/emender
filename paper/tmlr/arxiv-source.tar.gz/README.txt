Emending Nonlinear Recurrence: identified preprint packaging.
Compile main.tex with pdflatex + BibTeX (or Tectonic).
The preprint option is selected explicitly in main.tex.
Official TMLR style revision is recorded in STYLE-COMMIT; see LICENSE.
The anonymous submission PDF is distributed separately.
